#version 330 compatibility
// LoPo Pixel: the LoPo Studio look for Minecraft (Iris / OptiFine format).
// The finished frame is cut into big "pixels" (320x180 by default), each one takes the colour and depth at its centre,
// then the colour is dithered onto a palette and outlines are drawn from depth jumps - same rules as LoPo Studio.

uniform sampler2D colortex0;
uniform sampler2D depthtex0;
uniform float viewWidth;
uniform float viewHeight;
uniform float near;
uniform float far;

in vec2 texcoord;
layout(location = 0) out vec4 fragColor;

#define PIXEL_H 180 // [72 90 108 120 144 180 216 240 270 360 540]
#define PALETTE 1 // [0 1 2 3 4]
#define DITHER 0 // [0 1 2 3 4]
#define DITHER_STR 1.0 // [0.0 0.25 0.5 0.75 1.0 1.25 1.5 2.0]
#define LEVELS 5 // [2 3 4 5 6 8 12 16]
#define OUTLINE 2 // [0 1 2]
#define OL_THR 0.06 // [0.02 0.03 0.04 0.06 0.08 0.10 0.15 0.20 0.30]
#define SATURATION 1.15 // [0.6 0.8 1.0 1.15 1.3 1.5 1.8]
#define BRIGHTNESS 1.0 // [0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.5]

// ---------- palettes (copied from LoPo Studio) ----------
#if PALETTE == 1 // Болото
const int PN = 53;
const int PAL[PN] = int[PN](0x1b2928, 0x08151a, 0x172440,
	0x1c3440, 0x395e74, 0x2b9886, 0x3fbf98, 0x8cef8b,  0x36202e, 0x77404a, 0xbd6e5a, 0xe6a37a, 0xffd8a8,
	0x26122a, 0x681e34, 0xb5393f, 0xe6654a, 0xffae6e,  0x141a38, 0x243878, 0x3a64c2, 0x5ea1e6, 0xa6e2ff,
	0x38291c, 0x785822, 0xc2982a, 0xeacd4a, 0xfff59e,  0x181a22, 0x383c4a, 0x626879, 0x989eaf, 0xdee2ea,
	0x1e132e, 0x482969, 0x7a45a6, 0xae70d4, 0xe6aeff,  0x1d130f, 0x482d1f, 0x784b2f, 0xa67349, 0xd6a777,
	0x5a1622, 0xc23a2a, 0xf07a2a, 0xffc94a, 0xfff4c4,  0x102a22, 0x1d5236, 0x2e8040, 0x58b84a, 0xb2ee6a);
const int OL = 0x08151a; const int SH = 0x172440;
#elif PALETTE == 2 // PICO-8
const int PN = 16;
const int PAL[PN] = int[PN](0x000000, 0x1d2b53, 0x7e2553, 0x008751, 0xab5236, 0x5f574f, 0xc2c3c7, 0xfff1e8,
	0xff004d, 0xffa300, 0xffec27, 0x00e436, 0x29adff, 0x83769c, 0xff77a8, 0xffccaa);
const int OL = 0x000000; const int SH = 0x1d2b53;
#elif PALETTE == 3 // Game Boy
const int PN = 4;
const int PAL[PN] = int[PN](0x0f380f, 0x306230, 0x8bac0f, 0x9bbc0f);
const int OL = 0x0f380f; const int SH = 0x0f380f;
#elif PALETTE == 4 // Закат
const int PN = 48;
const int PAL[PN] = int[PN](0x2b1b33, 0x120a18, 0x1d1433,
	0x14303a, 0x1f5a5e, 0x2f9488, 0x5fd1a6, 0xc2fcd2,  0x3d1f3a, 0x8a3b4f, 0xd4615a, 0xf59a6b, 0xffd3a1,
	0x2a0f22, 0x6e1f3a, 0xb8344a, 0xe85a5a, 0xffa08a,  0x211a3d, 0x3f3378, 0x6a54b0, 0x9d86de, 0xd9c8ff,
	0x3a2218, 0x7a4a22, 0xc4842a, 0xf0c24a, 0xfff3a0,  0x1c1622, 0x3b3242, 0x655a6b, 0x9a8f9c, 0xddd3dc,
	0x1e1030, 0x41205c, 0x6c3590, 0xa05cc4, 0xdca6f0,  0x2a1612, 0x57301f, 0x8a5133, 0xb97b4f, 0xe6b07e,
	0x5a1622, 0xc23a2a, 0xf07a2a, 0xffc94a, 0xfff4c4);
const int OL = 0x120a18; const int SH = 0x1d1433;
#else // free colours: every channel posterized to LEVELS steps
const int OL = 0x08151a; const int SH = 0x172440;
#endif

vec3 hx(int h) { return vec3(float((h >> 16) & 255), float((h >> 8) & 255), float(h & 255)) / 255.0; }

// ---------- pixel grid ----------
float cellSz() { return max(1.0, floor(viewHeight / float(PIXEL_H) + 0.5)); }
ivec2 gridN() { return ivec2(ceil(vec2(viewWidth, viewHeight) / cellSz())); }
ivec2 centerTexel(ivec2 c) { return ivec2(clamp((vec2(c) + 0.5) * cellSz(), vec2(0.0), vec2(viewWidth, viewHeight) - 1.0)); }
float rawDepth(ivec2 c) { return texelFetch(depthtex0, centerTexel(c), 0).r; }
float linDepth(float d) { return 2.0 * near * far / (far + near - (2.0 * d - 1.0) * (far - near)); }
bool inGrid(ivec2 c) { ivec2 n = gridN(); return c.x >= 0 && c.y >= 0 && c.x < n.x && c.y < n.y; }

const float BAY[16] = float[16](0., 8., 2., 10., 12., 4., 14., 6., 3., 11., 1., 9., 15., 7., 13., 5.);
float bayer(ivec2 q) { return (BAY[(q.y & 3) * 4 + (q.x & 3)] + 0.5) / 16.0; }

float dist2(vec3 a, vec3 b) { vec3 d = a - b; return dot(d * d, vec3(0.3, 0.59, 0.11)); }

#if PALETTE != 0
// nearest and second-nearest palette colours
void nearest2(vec3 c, out vec3 c0, out vec3 c1, out float d0, out float d1) {
	d0 = 1e9; d1 = 1e9; c0 = c; c1 = c;
	for (int i = 0; i < PN; i++) {
		vec3 q = hx(PAL[i]); float e = dist2(c, q);
		if (e < d0) { d1 = d0; c1 = c0; d0 = e; c0 = q; } else if (e < d1) { d1 = e; c1 = q; }
	}
}
vec3 nearest(vec3 c) { vec3 a, b; float x, y; nearest2(c, a, b, x, y); return a; }
#endif

vec3 quantize(vec3 c, ivec2 q) {
	bool ck = ((q.x + q.y) & 1) == 1;
	float lum = dot(c, vec3(0.3, 0.59, 0.11));
#if DITHER == 2 || DITHER == 3 // picoCAD grid: flat colour or a 50% checkerboard of the two nearest colours; 3 = darkest parts go to the shadow colour
	#if DITHER == 3
	if (lum < 0.07) return hx(SH);
	if (lum < 0.13) return ck ? hx(SH) : c * 1.6;
	#endif
	#if PALETTE != 0
	vec3 c0, c1; float d0, d1; nearest2(c, c0, c1, d0, d1);
	float t = sqrt(d0) / max(sqrt(d0) + sqrt(d1), 1e-5);
	return (t > 0.32 * DITHER_STR && ck) ? c1 : c0;
	#else
	float L = float(LEVELS - 1); vec3 v = c * L, b = floor(v), f = v - b;
	vec3 up = ck ? step(vec3(0.32), f) : step(vec3(0.68), f); // mid tones become a 50% checkerboard
	return clamp((b + up) / L, 0.0, 1.0);
	#endif
#else
	float th;
	#if DITHER == 0
	th = bayer(q);
	#elif DITHER == 1
	th = ck ? 0.7 : 0.3;
	#else
	th = 0.5;
	#endif
	#if PALETTE != 0
	return nearest(c + (th - 0.5) * 0.16 * DITHER_STR);
	#else
	float L = float(LEVELS - 1); vec3 v = c * L, b = floor(v), f = v - b;
	return clamp((b + step(vec3(0.5) + (th - 0.5) * DITHER_STR, f)) / L, 0.0, 1.0);
	#endif
#endif
}

void main() {
	float cs = cellSz();
	ivec2 cell = ivec2(floor(gl_FragCoord.xy / cs));
	ivec2 q = ivec2(cell.x, gridN().y - 1 - cell.y); // dither pattern counted from the top-left, like LoPo Studio

	vec3 col = texelFetch(colortex0, centerTexel(cell), 0).rgb;
	float l = dot(col, vec3(0.3, 0.59, 0.11));
	col = clamp(mix(vec3(l), col, SATURATION) * BRIGHTNESS, 0.0, 1.0);

#if OUTLINE > 0
	float d = rawDepth(cell);
	bool sky = d >= 1.0;
	float z = linDepth(d), k = 1.0 / max(z, 0.01);
	ivec2 N[4] = ivec2[4](ivec2(-1, 0), ivec2(1, 0), ivec2(0, -1), ivec2(0, 1));
	for (int i = 0; i < 4; i++) {
		ivec2 n = cell + N[i];
		if (!inGrid(n)) continue;
		float dn = rawDepth(n);
		if (dn >= 1.0) continue;
		// outer outline: sky next to geometry
		if (sky) { fragColor = vec4(hx(OL), 1.0); return; }
	#if OUTLINE == 2
		// inner outline: a neighbour clearly closer AND a kink in 1/z (1/z is linear across any flat surface, so slopes stay clean)
		float zn = linDepth(dn);
		if (zn < z - max(0.05, z * OL_THR)) {
			ivec2 m = cell - N[i];
			float km = (inGrid(m) && rawDepth(m) < 1.0) ? 1.0 / max(linDepth(rawDepth(m)), 0.01) : k;
			if (abs(1.0 / max(zn, 0.01) + km - 2.0 * k) > k * OL_THR * 0.5) { fragColor = vec4(hx(OL), 1.0); return; }
		}
	#endif
	}
#endif

	fragColor = vec4(quantize(col, q), 1.0);
}
